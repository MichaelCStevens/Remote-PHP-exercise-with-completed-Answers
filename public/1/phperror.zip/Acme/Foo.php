<?php
namespace Acme;

class Foo
{
	public function bar()
	{
		return 'FooBar!';
	}
}