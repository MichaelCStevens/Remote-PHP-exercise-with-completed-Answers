<?php
namespace Swarming;

class Fizz
{
	public function buzz()
	{
		$foo = new Foo;

		return $foo->bar();
	}
}