<h1>1. Solve the below error.</h1>

<?php

require 'Acme/Foo.php';
require 'Swarming/Fizz.php';

$fizz = new Swarming\Fizz;

echo $fizz->buzz();

?>

<hr>

<p><a href="/2">Test 2: FizzBuzz</p>
